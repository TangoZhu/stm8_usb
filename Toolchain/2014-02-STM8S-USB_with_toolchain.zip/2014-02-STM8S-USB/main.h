/*
 * File: main.h
 * Date: 02.01.2013
 * Denis Zheleznyakov aka ZiB @ http://ziblog.ru
 */

#ifndef MAIN_H_
#define MAIN_H_

#include "stm8s.h"

#include "macros.h"

#include "mcu_gpio.h"

#include "usb.h"

#endif /* MAIN_H_ */
